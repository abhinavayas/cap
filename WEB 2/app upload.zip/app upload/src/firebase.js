import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import 'firebase/compat/firestore';
import 'firebase/compat/storage';

const firebaseApp = firebase.initializeApp({
  apiKey: "AIzaSyAZzAvO9xUHZ6ouFQKNq4Hb3oU8GrwkFUQ",
  authDomain: "bytebash-cdp.firebaseapp.com",
  projectId: "bytebash-cdp",
  storageBucket: "bytebash-cdp.appspot.com",
  messagingSenderId: "1020911396361",
  appId: "1:1020911396361:web:c62cc05603e12ffbd5bad8",
  measurementId: "G-NF385PH4RN"
  });
  
  const db = firebase.firestore();
  const auth = firebase.auth();
  const storage = firebase.storage();
  
  export { db, auth, storage };
  