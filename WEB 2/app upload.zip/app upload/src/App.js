import './App.css';
import { useState } from 'react';
import { useEffect } from 'react';
import Header from './component/header';
import Post from './component/post';
import Login from './component/login';
import Profiles from './component/profiles';
import {db} from "./firebase"

function App() {
  const [displayName , setDisplayName] = useState("")
  const [home , setHome] = useState(false)
  const [width , setWidth] = useState(window.innerWidth)
  const [height , setHeight] = useState(window.innerHeight)
  const [userPhoto , setUserPhoto] = useState("")
  const [profiles , setProfiles] = useState([])


useEffect (()=> {
  function watch () {
    setWidth(window.innerWidth)
    setHeight(window.innerHeight)
  }
    window.addEventListener ("resize" , watch)  
    return function (){
      window.removeEventListener ("resize" , watch)
    }
  } , [])

  useEffect(() => {
    db.collection("users")
        .onSnapshot(snapshot => {
            setProfiles(snapshot.docs.map(doc => {
                const data = doc.data()
                data.id = doc.id
                return data;
            }
            )
            )})
        }, [])

        const profiles_tag = profiles.map(profile => {
          return ( <Profiles
            key = {profile.id}
            id = {profile.id}
            displayName = {profile.displayName}
            userPhoto = {profile.userPhoto}
            />)
        })
        let style = {
        
        }
        if (width > 800) {
         style = {
          "margin-left" : (Math.round((width - 700) / 2) )  +"px"
        }
      }
       
  return (
    <div className="App">

      <div>  
      {
        home && 
          <div>   
            <Header 
            profilePhoto = {userPhoto}
            username = {displayName}
            />
            
            <div className='app-grid-parent' style = {style}>
            <div className='app-grid'>
              <div>
                  <Post 
                    username = {displayName}
                    user_photo = {userPhoto}
                  />
          </div>
            <div className='profiles-parent'>  
        {profiles_tag}
        </div>  </div></div>
          </div>
      }
      {
        !home &&  
          <Login 
            setHome = {setHome} 
            setDisplayName = {setDisplayName}
            width = {width}
            height = {height}
            setUserPhoto = {setUserPhoto}
            />
      }
       </div>

    </div>
  );
}

export default App;
