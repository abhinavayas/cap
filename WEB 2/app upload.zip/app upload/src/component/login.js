import "../style/login.css"
import { useState } from "react"
import SignUp from "./signup"
import {db ,auth} from "../firebase.js"

export default function Login({setHome , setDisplayName , width , height , setUserPhoto}) {

    const [email , setEmail] = useState("")
    const [Password , setPassword] = useState("")
    const [login , setLogin] = useState(true)
    const [signup , setSignup] = useState(false)
    const [errorText , seterrorText] = useState("")

    let userInfo = []
   

    const handleLogin = (event) => {
        event.preventDefault()
        let email_this = email + "@test.com"
        auth.signInWithEmailAndPassword(email_this , Password)
            .then(firebaseuser => {
                db.collection("users")
                    .onSnapshot(snapshot => {
                        snapshot.docs.map(doc => {
                            if(doc.id == email) {
                                userInfo= doc.data()
                                setDisplayName(userInfo.displayName)
                                setUserPhoto(userInfo.userPhoto)
                            }
                            
                        })
                    })      
                setLogin(false)
                setHome(true)
            }).catch(error => {
            //    seterrorText(error.message)
            seterrorText("Account not found")
            })
    }
    let style  = {
        width : width * 0.9
    }
    let style_fiv  = {
        height : height 
    }
    return (
        <div className="form-parent" style={style_fiv} >
        <div>
            { login && 
            <div className="login" style = {style}>
                   <img 
                className = "form-image"
                src = "https://abhinavayas.github.io/cap/hosted/A.K.png"
                alt = "instagram banner"
            />
                <form className="form-login">
                    <p className="input-label" >  Username  </p>
                    <input
                        type="text"
                        className="input-box"
                        value = {email}
                        onChange={event => setEmail(event.target.value)}
                        />
                    <p className="input-label">Password</p>
                    <input
                        type="password"
                        className="input-box"
                        value = {Password}
                        onChange={event => setPassword(event.target.value)}
                        />
                    <button
                        className="form-button"
                        onClick={handleLogin}
                        >
                            Log In
                    </button>
                    <p className="error-text"> {errorText} </p>
                </form>
                < div className="login-text">
               
                <h4 >New user ? </h4>
                 <button 
                className="form-button-inline"
                onClick= {() =>{setSignup(true); setLogin(false)  }}  >Sign up</button> 
               
            </div> </div>
            }
            {
                signup && <SignUp setDisplayName_home = {setDisplayName} setHome ={setHome} setLogin ={setLogin} setSignup = {setSignup} width={width} height={height} setUserPhoto = {setUserPhoto}/>
            }
            </div>
        </div>
    )
}