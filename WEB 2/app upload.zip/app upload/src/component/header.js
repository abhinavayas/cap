import "../style/header.css"
import { useState , useEffect } from "react"
import {db , storage} from "../firebase.js"
import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import 'firebase/compat/firestore';
import 'firebase/compat/storage';


export default function Header ({username , profilePhoto}) {
   
    const [uploadImagestat , setUploadImagestat] = useState(false)
    const [caption , setCaption] = useState("")
    const[progress , serProgress] = useState(0)
    const [image , setImage] = useState(null)
    const [progressbarShow , setProgressbarShow] = useState(false)
    const [showImage , setShowImage] = useState(false)

    useEffect(() => {
        if (showImage) {
            var image_x = document.getElementById('userToUpload');
            image_x.src = URL.createObjectURL(image);
        }
    }, [showImage , image])

    const loadFile = (event) => {
        setShowImage(true)
        setUploadImagestat(true)
        setImage(event.target.files[0])
    }


    const handleUploadPost = () => {
        setShowImage(false)
        setUploadImagestat(false)
        let file_name = String (image.name + ( Math.random() * 1000000000 ) + image.name +  ( Math.random() * 100000000 ) + image.name +  ( Math.random() * 100000000 ))
        
        const uploadTask = storage.ref("/posts/" + file_name )
                                    .put(image)
        uploadTask.on(
            "state_changed" , (snapshot) => {
                setProgressbarShow(true)
                const progress_upload = Math.round(
                    (snapshot.bytesTransferred / snapshot.totalBytes) * 100
                )
                serProgress(progress_upload)
                if (progress_upload == 100) {
                    setProgressbarShow(false)
                    setCaption("")
                    serProgress(0)
                }
            }, 
            (error) => {
                alert(error.message)
            },
            () => {
                storage.ref("posts")
                        .child(file_name)
                        .getDownloadURL()
                        .then ((url) => {
                            db.collection("posts")
                                .add({
                                    timestamp : firebase.firestore.FieldValue.serverTimestamp(),
                                    username : username,
                                    image : url,
                                    caption : caption,
                                    user_photo : profilePhoto
                                })
                        })
            }
        )
       
    }

    return (
        <div>     
        <div className = "header-parent">
        <div className = "header">
            <img 
                className = "header-image"
                src = "https://abhinavayas.github.io/cap/hosted/A.K.png"
                alt = "instagram banner"
            /> 
          <div className = "header-div">  
            <input  className = "header-upload"  type="file"  accept="image/*" onChange = {loadFile} id="actual-btn" hidden/>
            <label for="actual-btn">  
                <img 
                    className = "header-upload-image"
                    src = "https://abhinavayas.github.io/cap/hosted/asset/upload.png"
                    alt = "instagram banner"
                    /></label>
            </div>
            </div> 
            </div>
            { showImage &&
            <img 
                className="image-to-upload"
                id = "userToUpload"
                />
            }
      {
            uploadImagestat &&
            <div>
<div className = "addComment">
            <div> 
            <img 
                src = {profilePhoto}
                className = "addComment-photo"
                alt = ""
                />
                 </div>
                 <div>   
            <input 
                type = "text"
                className = "addComment-input"
                value = {caption}
                placeholder="Add a caption..."
                onChange={(e) => setCaption(e.target.value)}
                />
                </div>
                <div>
                    <button className ="addComment-button" onClick={handleUploadPost} > Post</button>
                </div>
        </div>
       
                </div>
        }
         { progressbarShow && <div> 
        <progress value = {progress} max = "100" />
        </div>
        }
        </div>
    )
}