import "../style/profiles.css"

export default function Profiles ({id , displayName,userPhoto}) {
    return (
        <div className="profiles">
              <div className="profiles-header">
                <img
                    className="profiles-header-image"
                    src = {userPhoto}
                    alt = "profiles-profile picture"
              />
                <h5 className="profiles-text" >{displayName}</h5>
            </div>

        </div>
    )
}