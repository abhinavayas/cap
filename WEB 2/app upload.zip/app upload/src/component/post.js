import React from "react"
import { useState , useEffect } from "react"
import { db } from "../firebase"
import "../style/post.css"
import PostGUI from "./GUI/postGUI"


export default function Post (username , user_photo) {
    const [posts , setPosts] = useState([])

    useEffect(() => {
        db.collection("posts")
        .orderBy("timestamp", "desc")
            .onSnapshot(snapshot => {
                setPosts(snapshot.docs.map(doc => {
                    const data = doc.data()
                    data.id = doc.id
                    return data;
                }
                )
                )})
            }, [])

    const post_tag = posts.map (post => {
        return (
            <PostGUI
                key = {post.id}
                username={username}
                user_photo={post.user_photo}
                displayName={post.username}
                image={post.image}
                caption={post.caption}
                id = {post.id}
            />
        )
    })

    return (
        <div>
            {post_tag}
        </div>
    )
}
