import { useState , useEffect } from "react"
import { db } from "../../firebase"
import Comment from "../comment"
import AddComment from "../addComment"

export default function PostGUI ({ username , user_photo , displayName , caption , image , id }) {
    const [comments , setComments] = useState([])

    useEffect (() => {
        db.collection("posts")
            .doc(id)
            .collection("comments")
            .orderBy("timestamp", "desc")
            .onSnapshot(snapshot => {
                setComments(snapshot.docs.map(doc =>  {
                    const data = doc.data()
                    data.id = doc.id
                    return data;
                }))
            })
    }, [] )

    const comment_tag = comments.map (comment => {
        return(
            <Comment
                key = {comment.id}
                id = {comment.id}
                displayName = {comment.displayName.username}
                profilePhoto = {comment.profilePhoto}
                comment = {comment.comment}
        />
        )
    }
    )

    return (
        <div className="post">
            <div className="post-header">
                <img
                    className="post-header-image"
                    src = {user_photo}
                    alt = "profile picture"
              />
                <h4 className="post-header-text" >{displayName}</h4>
            </div>
            <img
                className="post-image"
                src = {image}
                alt = "post image"
            />
          
            <h5 className = "caption" >
                <strong>{displayName} </strong> {caption}
            </h5>
            <AddComment 
                username= {username}
                id = {id}
                profilePhoto ={user_photo}
                />
                <div className="comment-div-parent">  
           {comment_tag}
           </div>
        </div>
    )
}