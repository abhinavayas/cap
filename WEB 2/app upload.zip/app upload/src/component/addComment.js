import {useState} from "react"
import "../style/addComment.css"
import {db} from "../firebase.js"
import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import 'firebase/compat/firestore';
import 'firebase/compat/storage';

export default function AddComment ({username , id , profilePhoto}) {
    const [comment , setComment] = useState("")
    const handleUpload = () => {
        const comm = comment
        setComment("")
        db.collection("posts")
            .doc(id)
            .collection("comments")
            .add({
                timestamp : firebase.firestore.FieldValue.serverTimestamp(),
                comment : comm,
                displayName : username,
                profilePhoto : profilePhoto
            })
            
    }


    return (
        <div className = "addComment">
            <div> 
            <img 
                src = {profilePhoto}
                className = "addComment-photo"
                alt = ""
                />
                 </div>
                 <div>   
            <input 
                type = "text"
                className = "addComment-input"
                value = {comment}
                placeholder="Add a comment..."
                onChange={(e) => setComment(e.target.value)}
                />
                </div>
                <div>
                    <button className ="addComment-button" onClick={handleUpload} > Post</button>
                </div>
        </div>
    )
}