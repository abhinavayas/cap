import "../style/comment.css"

export default function Comment ({displayName , profilePhoto , comment }) {
    return (
    <div className="comment-parent">  
    <div className="comment">
        <div className="comment-col-1">
            <img
                className="comment-user-photo"
                src = {profilePhoto}
                alt = ""
            />
            </div>
        <div className="comment-col-2">
            <h5 className="comment-user-displayName">{displayName}</h5>
            <h5 className="comment-comment">{comment}</h5>
        </div>
        </div>
    </div>)
}
