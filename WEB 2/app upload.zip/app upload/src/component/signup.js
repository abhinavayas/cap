
import { useState } from "react"
import {db , auth} from "../firebase.js"
import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';

export default function SignUp({setDisplayName_home , setHome , setLogin , setSignup , width , height , setUserPhoto}) {

    const [email , setEmail] = useState("")
    const [Password , setPassword] = useState("")
    const [errorText , seterrorText] = useState("")

    const handleSignup = (event) => {  
        let signupError = ""
        let name = email
        const pp =  "https://abhinavayas.github.io/cap/hosted/asset/" + String(Math.round (Math.random() *18 ))   + ".png"
        event.preventDefault()
        let this_email = email + "@test.com"
        auth.createUserWithEmailAndPassword(this_email,Password)
        .catch(error => {
            signupError = error.message
            seterrorText(error.message)    

            if (error.message === "Firebase: Password should be at least 6 characters (auth/weak-password).") {
                seterrorText("Password must be at least 6 characters.")  
            }
            if (error.message === "Firebase: The email address is already in use by another account. (auth/email-already-in-use).") {
                seterrorText("User already exists.")  
            }
        })

    firebase.auth().onAuthStateChanged(user => {
        if (user) {
            if (signupError.length < 1 ) {
                db.collection("users")
                    .doc(name)
                    .set({
                        displayName : email,
                        userPhoto : pp
                    })
            setUserPhoto (pp)
            setDisplayName_home(name);
            setSignup(false)
            setHome(true)
        }}
    })
    }
    let style  = {
        width : width * 0.9
    }
    let style_fiv  = {
        height : height 
    }
    return (
        <div className="form-parent" style = {style_fiv}>
        <div className="signup" style = {style}>
        <img 
                className = "form-image"
                src = "https://abhinavayas.github.io/cap/hosted/A.K.png"
                alt = "instagram banner"
            />
            <form>
   
            <p className="input-label">New Username</p>
                <input
                    type="text"
                    className="input-box"
                    value = { email}
                    onChange={event => setEmail(event.target.value)}
                    />
                <p className="input-label">New Password</p>
                <input
                    type="password"
                    className="input-box"
                    value = { Password}
                    onChange={event => setPassword(event.target.value)}
                    />
                <button
                    className="form-button"
                    onClick= {handleSignup}
                    >
                        Sign Up Now
                </button>
            </form>
            <p className="error-text"> {errorText} </p>
            <div className="signup-text">
            <h4>Already a user ? </h4> <button
            className="form-button-inline"
            onClick= {() => {setSignup(false); setLogin(true); }  } > Log in </button>
            </div>
        </div>
        </div>
    )
}