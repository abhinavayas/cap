import { useState } from "react"
import joinChannel from "../functions/joinChannel";
import getJoinedChannels from "../functions/getJoinedChannels";
import getWalletAddress from "../functions/getWalletAddress";

export default function JoinChannel () {
    const [channel_uid, set_channel_uid]= useState("");
    const [res, setRes]= useState("");

    async function handleJoinChannelClick () {
         setRes("Joining Channel...")
         const res= await joinChannel(channel_uid);
         var address= await getWalletAddress;
         const joined= await getJoinedChannels(address);
         let found= false;
         for (var i= 0; i < joined.length; i++) {
            if (channel_uid == joined[i]) {
                found= true;
            }
         }
         setRes(found? "Joined Channel Successfuly..." : "Unable to join Channel...")
    }

    return (
        // <div className="bg-green-400 h-screen w-full">
        //     <p>Enter uid of the channel</p>
        //     <input type= "text" value= {channel_uid} onChange={(e) => set_channel_uid(e.target.value)}></input>
        //     <button className="bg-blue-300" onClick={handleJoinChannelClick}>Join Channel</button>
        //     <p> {res} </p>
        // </div>
        <div className="w-full h-full">  
        <div className="w-full flex justify-center">
                    <div className="my-[100px]">
                        <div className="border-2 border-indigo-300 w-fit px-4 py-4 rounded-3xl">
                        <input className="border-4 px-5 py-1 rounded-3xl" type= "text" value= {channel_uid} onChange={(e) => set_channel_uid(e.target.value)}/>  
                        <button className="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 px-5 py-2 rounded-2xl text-white font-bold mx-3"  onClick={handleJoinChannelClick}>Join Channel</button>
                    </div>
                </div>
            </div> 
            </div>
    )
}