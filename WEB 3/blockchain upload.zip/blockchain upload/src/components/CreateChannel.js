import { useState } from "react"
import createChannel from "../functions/createChannel"
import getChannelName from "../functions/getChannelName";

export default function CreateChannel () {

    const [channelName, setChannelName]= useState("");
    const [channel_description, set_channel_description]= useState("");
    const [uid, setUid]= useState("");
    const [res, setRes]= useState("");

    async function handleCreateChannelClick () {
        setRes("Creating Channel...");
         const res= await createChannel(uid, channelName, channel_description);
         var nameToId= await getChannelName(uid);
         if (nameToId == channelName){
            setRes("Channel created with uid: " + uid);
         } else {
            setRes("Channel already exists or Unknown error...")
         }
         
    }

    return (
        // <div className="bg-green-400 h-screen w-full">
        //     <p>Enter a Unique uid for your channel</p>
        //     <input type= "text" value= {uid} onChange={(e) => setUid(e.target.value)} ></input>
        //     <br />
        //     <hr />
        //     <p>Enter a Name for your channel</p>
        //     <input type= "text" value= {channelName} onChange={(e) => setChannelName(e.target.value)}></input>
        //     <br />
        //     <hr />
        //     <p>Enter a Description for your channel.</p>
        //     <input type= "textarea" value= {channel_description} onChange={(e) => set_channel_description(e.target.value)}></input>
        //     <button className="bg-blue-300" onClick={handleCreateChannelClick}>Create Channel</button>
        //     <p> {res} </p>
        // </div>
        <div className="w-full h-full">  
            <div className="w-full flex justify-center">
                    <div className="my-[100px]">
                        <div className="border-2 border-indigo-300 w-fit px-4 py-4 rounded-3xl ">
                        <input placeholder="UID" className="border-4 px-5 py-1 rounded-3xl" type= "text" value= {uid} onChange={(e) => setUid(e.target.value)}/>  <br /><br />
                        <input placeholder="Channel Name" className="border-4 px-5 py-1 rounded-3xl" type= "text" value= {channelName} onChange={(e) => setChannelName(e.target.value)}/>  <br /> <br />
                        <input placeholder="Channel Description" className="border-4 px-5 py-1 rounded-3xl" type= "text" value= {channel_description} onChange={(e) => set_channel_description(e.target.value)}/>  <br /> <br />
                        <div className="w-full flex justify-center"><button className="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 px-5 py-2 rounded-2xl text-white font-bold mx-3"  onClick={handleCreateChannelClick}>Create Channel</button></div>
                    </div>
                </div>
            </div> 
        </div>
    )
}