import { useEffect, useState } from "react";
import getMessageInfo from "../functions/getMessageInfo"
import addMessage from "../functions/addMessage";

export default function CommunityPage ({ch_uid}) {

    const [messages, setMessages]= useState([]);
    const [uploadMessage, setMessageUpload]= useState("");
    const [showPopup, setShowPopup]= useState(false);

    useEffect (() => {
        async function getMesssages () {
            setMessages(["Loading..."]);
            const messages_x= await getMessageInfo(ch_uid);
            setMessages(messages_x);
        }
        getMesssages();
    }, [ch_uid])

    function handlePopup () {
        setShowPopup(prevVal => !prevVal);
    }

    async function handleMesageUpload () {
        await addMessage(ch_uid, uploadMessage);
    }

    return (
        <div className="w-full h-full">
            <div className="px-5 w-full h-full py-8 ">
                <div className="flex justify-between border-b-2 py-2 border-indigo-300">
                    <h1 className="text-2xl font-black"> {ch_uid} </h1>
                    <div>
                        <button className="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 px-5 py-2 rounded-2xl text-white font-bold" onClick={handlePopup}>Announce</button>
                    </div>
                </div>
            {!showPopup && <div className="py-7">
                {messages.map(msg => {
                    return (
                        <div className="bg-indigo-100 w-fit px-5 py-2 rounded-2xl my-3">  
                            {msg}
                        </div>
                    )
                })}
            </div>}
            {showPopup && 
                <div className="w-full flex justify-center">
                    <div className="my-[100px]">
                        <div className="border-2 border-indigo-300 w-fit px-4 py-4 rounded-3xl">
                        <input className="border-4 px-5 py-1 rounded-3xl" type= "text" value= {uploadMessage} onChange={(e) => setMessageUpload(e.target.value)}></input>
                        <button className="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 px-5 py-2 rounded-2xl text-white font-bold mx-3"  onClick= {handleMesageUpload}>Add</button>
                    </div>
                </div> 
            </div>  }
            </div>
        </div>
    )
}