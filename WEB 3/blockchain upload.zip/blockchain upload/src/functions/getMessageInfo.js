async function getMessageInfo ( uid){
    const alchemi_apiKey = "ZneL436DQf-nVFmF0HydnVVC-bsK0Qyu"
    const web3 = new window.Web3('https://eth-goerli.alchemyapi.io/v2/'+alchemi_apiKey); 
    
    const contractAddress = '0xE62ED56809AF5dB84dd58BE1d1Fc875ef0B57f17';
    const abi = [{"inputs":[{"internalType":"string","name":"_uid","type":"string"},{"internalType":"string","name":"_mesage","type":"string"}],"name":"addMessage","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"_uid","type":"string"},{"internalType":"string","name":"_name","type":"string"},{"internalType":"string","name":"_description","type":"string"}],"name":"createChannel","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"_uid","type":"string"}],"name":"getChannelDescription","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"string","name":"_uid","type":"string"}],"name":"getChannelName","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_reqAddress","type":"address"}],"name":"getJoinedChannels","outputs":[{"internalType":"string[]","name":"","type":"string[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"string","name":"_uid","type":"string"}],"name":"getMessageInfo","outputs":[{"internalType":"string[]","name":"","type":"string[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"string","name":"_uid","type":"string"}],"name":"getMessageTimestamp","outputs":[{"internalType":"uint256[]","name":"","type":"uint256[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"string","name":"_uid","type":"string"}],"name":"joinChannel","outputs":[],"stateMutability":"nonpayable","type":"function"}];
    
    const contract = new web3.eth.Contract(abi, contractAddress);
    const channels = await contract.methods.getMessageInfo(uid).call();

    return channels;
}

export default getMessageInfo;