async function getWalletAddress () {
    await window.ethereum.request({ method: 'eth_requestAccounts' });
    const provider = new window.ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const address = await signer.getAddress();
    console.log('Public Address:', address);
    return await address.toString();
  }

  export default getWalletAddress;