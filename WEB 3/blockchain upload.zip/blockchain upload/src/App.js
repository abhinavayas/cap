import { useEffect, useState } from 'react';
import './App.css';
import getWalletAddress from './functions/getWalletAddress';
import CreateChannel from './components/CreateChannel';
import JoinChannel from './components/JoinChannel';
import getJoinedChannels from './functions/getJoinedChannels';
import CommunityPage from './components/CommunityPage';

function App() {
  const [showCreateChannel, set_showCreateChannel]= useState(false);
  const [showJoinChgannel, set_showJoinChgannel]= useState(false);
  const [joinedChannels, setJoinedChannels]= useState([]);
  const [showCommunitypPage, set_showCommunitypPage]= useState(false);
  const [clickUid, setC_clickUid]= useState("");

  function handleCreateChannelClick () {
    set_showCreateChannel(true);
    set_showJoinChgannel(false);
    set_showCommunitypPage(false);
  }
  function handleJoinChannelClick () {
    set_showJoinChgannel(true);
    set_showCreateChannel(false);
    set_showCommunitypPage(false);
  }
  function handleCommunityClick (e) {
    set_showCommunitypPage(false);
    setC_clickUid(e.target.id);
    set_showJoinChgannel(false);
    set_showCreateChannel(false);
    set_showCommunitypPage(true);
  }
  useEffect(() => {
    async function renderChannels () {
      try {
      const joinedChannels_x= await getJoinedChannels(await getWalletAddress());
      setJoinedChannels(joinedChannels_x);
      console.log("hello");
      }catch(e) {
        console.log(e);
      }
    }
    renderChannels();
  }, []) 


  
  console.log("hello");
  return (
    <div>
      <div> 
        <div className="flex w-100 h-screen bg-white bg-black flex justify-center">
          <div className= "w-[300px] h-screen bg-blue-300">

          <div className= "h-[60px] w-full bg-blue-700 ">  
            <div>
              <h1 className= "text-white text-3xl px-4 py-4 font-black"> Ayas Block </h1>
            </div>
              <div className='my-6'>  
              {
                joinedChannels.map(channel => {
                  return (
                    <button 
                      key= {channel}
                      id= {channel}
                      className='w-full h-[30px] bg-blue-500 text-white text-xl my-2 font-bold' 
                      onClick={e => handleCommunityClick(e)} >{channel}  </button>
                  )
                })
              }
                <button className='w-full h-[30px] bg-blue-700 text-white text-xl my-2' onClick={handleCreateChannelClick} >Create Channel</button>
                <button className='w-full h-[30px] bg-blue-700 text-white text-xl my-2' onClick={handleJoinChannelClick} >Join Channel</button>
              </div>
            </div>
          </div>

          {!showCreateChannel && !showJoinChgannel  && !showCommunitypPage && <div className='w-full h-scren bg-white-300'>
            <div className= "h-[60px] w-full bg-blue-700">
            </div>
          </div>}
          {showCreateChannel && <div className='w-full h-scren'>
            <div className= "h-[60px] w-full bg-blue-700">
            </div>
            <CreateChannel
            />
          </div>}
          {showJoinChgannel && <div className='w-full h-scren'>
            <div className= "h-[60px] w-full bg-blue-700">
            </div>
            <JoinChannel
            />
          </div>}
          {showCommunitypPage && <div className='w-full h-scren'>
            <div className= "h-[60px] w-full bg-blue-700">
            </div>
            <CommunityPage
              ch_uid= {clickUid}
            />
          </div>}
        </div>
      </div>  
    </div>
  );
}

export default App;
